curl --location 'https://bfhldevapigw.healthrx.co.in/automation-campus/create/user' \
--header 'roll-number: 1' \
--header 'Content-Type: application/json' \
--data-raw '{
"firstName": "Test' OR '1'='1",
"lastName": "User",
"phoneNumber": 9876543213,
"emailId": "testuser@example.com"
}'
