curl --location 'https://bfhldevapigw.healthrx.co.in/automation-campus/create/user' \
--header 'roll-number: 1' \
--header 'Content-Type: application/json' \
--data-raw '{
"firstName": "Test",
"lastName": "User",
"phoneNumber": 9876543212,
"emailId": "invalid-email-format"  # Invalid email
}'
