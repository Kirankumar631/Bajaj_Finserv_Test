curl --location 'https://bfhldevapigw.healthrx.co.in/automation-campus/create/user' \
--header 'roll-number: 1' \
--header 'Content-Type: application/json' \
--data-raw '{
"firstName": "Test",
"lastName": "User",
"phoneNumber": 12345,  # Invalid length
"emailId": "testuser@example.com"
}'
