# Test Case 1: Successful User Creation

curl --location 'https://bfhldevapigw.healthrx.co.in/automation-campus/create/user' \
--header 'roll-number: 1' \
--header 'Content-Type: application/json' \
--data-raw '{
"firstName": "John",
"lastName": "Doe",
"phoneNumber": 9876543210,
"emailId": "john.doe@example.com"
}'


# Test Case 2: Missing roll-number Header

curl --location 'https://bfhldevapigw.healthrx.co.in/automation-campus/create/user' \
--header 'Content-Type: application/json' \
--data-raw '{
"firstName": "John",
"lastName": "Doe",
"phoneNumber": 9876543210,
"emailId": "john.doe@example.com"
}'


# Test Case 3: Missing Required Field firstName

curl --location 'https://bfhldevapigw.healthrx.co.in/automation-campus/create/user' \
--header 'roll-number: 1' \
--header 'Content-Type: application/json' \
--data-raw '{
"lastName": "Doe",
"phoneNumber": 9876543210,
"emailId": "john.doe@example.com"
}'


# Test Case 4: Duplicate 'phoneNumber'

curl --location 'https://bfhldevapigw.healthrx.co.in/automation-campus/create/user' \
--header 'roll-number: 1' \
--header 'Content-Type: application/json' \
--data-raw '{
"firstName": "Jane",
"lastName": "Smith",
"phoneNumber": 9876543210,  # Use the same number from a previous successful case
"emailId": "jane.smith@example.com"
}'

# Test Case 5: Duplicate 'emailId'

curl --location 'https://bfhldevapigw.healthrx.co.in/automation-campus/create/user' \
--header 'roll-number: 1' \
--header 'Content-Type: application/json' \
--data-raw '{
"firstName": "Jane",
"lastName": "Smith",
"phoneNumber": 9876543211,
"emailId": "john.doe@example.com"  # Use the same email from a previous successful case
}'
